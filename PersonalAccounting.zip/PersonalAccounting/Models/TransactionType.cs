namespace PersonalAccounting.Models;

public enum TransactionType
{
    Income = 1,
    Expense = 2
}